var rim=window.rim||{};
rim.keyevent=function(){var a={},e=null,f=null;a.addDeferredKeyUpListener=function(b,c,d,g){a.addKeyUpListener(b,function(h){e!==null&&clearTimeout(e);e=setTimeout(function(){e=null;c(h)},g||230)},d)};a.addDeferredKeyDownListener=function(b,c,d){a.addKeyDownListener(b,function(g){f!==null&&clearTimeout(f);f=setTimeout(function(){f=null;c(g)},230)},d)};a.addKeyDownListener=function(b,c,d){b.addEventListener("keydown",c,d?true:false)};a.addKeyUpListener=function(b,c,d){b.addEventListener("keyup",c,
d?true:false)};return a}();
