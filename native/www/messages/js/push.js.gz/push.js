var rim=window.rim||{};rim.push=function(){var b={},c;b.initialize=function(a){c=a};b.addListener=function(a,d){c.addListener(a,d)};b.removeListener=function(a,d){c.removeListener(a,d)};return b}();
