angular.module('gettext').run(['gettextCatalog', function (gettextCatalog) {
/* jshint -W100 */
    gettextCatalog.setStrings('en_US', {"Dismiss":"Dismiss","Snooze (5 mins)":"Snooze (5 mins)","You left the chat":"You left the chat"});
/* jshint +W100 */
}]);