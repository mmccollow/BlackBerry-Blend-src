angular.module('gettext').run(['gettextCatalog', function (gettextCatalog) {
    for (var key in gettextCatalog.strings) {
        if (key === 'length' || !gettextCatalog.strings.hasOwnProperty(key)) continue;
        gettextCatalog.currentLanguage = key;
        break;
    }
}]);
