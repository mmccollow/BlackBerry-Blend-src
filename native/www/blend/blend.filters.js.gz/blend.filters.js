(function(a){a.angular.module("Blend.filters",["blend"])})(this);
